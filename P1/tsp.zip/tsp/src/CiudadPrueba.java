/**
 * Pruebas sobre la clase Ciudad
 */
public class CiudadPrueba {
   /**
    * Metodo main para pruebas
    * @param args
    */
   public static void main(String args[]){
      Ciudad ciudad1;
      ciudad1 = new Ciudad("Granada", 36.24, 11.17);
   }
}
